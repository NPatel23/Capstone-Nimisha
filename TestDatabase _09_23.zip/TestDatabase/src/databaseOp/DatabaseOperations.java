package databaseOp;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;


import model.Resource;
import model.FileData; 
import util.Database;

public class DatabaseOperations 
{
	 Connection connection;
	 PreparedStatement preparedStatement;
	 
    public DatabaseOperations() {
        connection = Database.getConnection();
    }
  
  
	public Resource getResourceById(String resourceId) 
	{
		// TODO Auto-generated method stub
		System.out.print(resourceId+ " From GetResourceId Method");
		Resource res=new Resource();
		try {
            preparedStatement = this.connection.prepareStatement("select * from resource where fname=?");
            System.out.println(" prepared "+preparedStatement.toString());
            preparedStatement.setString(1, resourceId);
            ResultSet rs = preparedStatement.executeQuery();
 
            if (rs.next()) {
            	res.setFname(rs.getString("fname"));
            	res.setLname(rs.getString("lname"));
            	res.setEmail(rs.getString("email"));
            	res.setDepartment(rs.getString("department"));
            	res.setBillRate(rs.getString("billRate"));
            	res.setCostRate(rs.getString("costRate"));
                res.setPermissions(rs.getString("permission"));
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
 
		
		
		return res;
	}

	public List<Resource> getAllResource() {
	        List<Resource> reses = new ArrayList<Resource>();
	        try {
	            Statement statement = (Statement) connection.createStatement();
	            ResultSet rs = statement.executeQuery("select * from resource");
	            while (rs.next()) {
	                Resource res = new Resource();
	            	res.setFname(rs.getString("fname"));
	            	res.setLname(rs.getString("lname"));
	            	res.setEmail(rs.getString("email"));
	            	res.setDepartment(rs.getString("department"));
	            	res.setBillRate(rs.getString("billRate"));
	            	res.setCostRate(rs.getString("costRate"));
	                res.setPermissions(rs.getString("permission"));
	                reses.add(res);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	 
	        return reses;
	    }


	public  void addResource(Resource res) {
		
		try {
             preparedStatement = connection
            		.prepareStatement("insert into resource(fname,lname,email,department,billRate,costRate,permission) values (?,?,?,?,?,?,? )");
            // Parameters start with 1
            preparedStatement.setString(1, res.getFname());
            preparedStatement.setString(2, res.getLname());
            preparedStatement.setString(3, res.getEmail());
            preparedStatement.setString(4, res.getDepartment());
            preparedStatement.setString(5, res.getBillRate());
            preparedStatement.setString(6, res.getCostRate());
            preparedStatement.setString(7, res.getPermissions());
           
            
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    
		
	}


	public int insertFileDataRow(String date ,String fName , String lName, String project, String hours) throws ClassNotFoundException,IllegalAccessException,InstantiationException,SQLException{
		Connection c = Database.getConnection();
    	Statement st = (Statement) c.createStatement();
		String sql ="INSERT INTO fileData  VALUES ('0','"+date+"', '"+fName+"', '"+lName+"','"+project+"', '"+hours+"')";
		int res =st.executeUpdate(sql);
		c.close();
		return res;
	}


	public List<FileData> getAllFileData() 
	{
		// TODO Auto-generated method stub
		  List<FileData> reses = new ArrayList<FileData>();
	        try {
	            Statement statement = (Statement) connection.createStatement();
	            ResultSet rs = statement.executeQuery("select * from filedata");
	            while (rs.next()) {
	                FileData res = new FileData();
	                
	                res.setDate(rs.getString("date"));
	            	res.setFname(rs.getString("fname"));
	            	res.setLname(rs.getString("lname"));
	            	res.setProject(rs.getString("project"));
	            	res.setHoure(rs.getString("hours"));
	                reses.add(res);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        System.out.println("From getAllFileData "+reses);
	        return reses;
	    }
	

}  

	

