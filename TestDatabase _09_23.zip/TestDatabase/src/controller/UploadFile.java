package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import databaseOp.DatabaseOperations;
import databaseOp.readFile;
import model.Resource;

/**
 * Servlet implementation class UploadFile
 */
@WebServlet("/UploadFile")
public class UploadFile extends HttpServlet {
	
	private static final long serialVersionUID = 1L;	
    private static String INSERT_OR_EDIT = "/home.jsp";  
    private  DatabaseOperations dao;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadFile() {
        super();
        dao = new DatabaseOperations();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.setAttribute("resources","TEST");
		RequestDispatcher view = request.getRequestDispatcher(INSERT_OR_EDIT);
        view.forward(request, response);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String filePath=request.getParameter("filepath");
		System.out.println("the path is "+filePath);
	     readFile rf=new readFile();
	     try {
	    	 System.out.println("inside try");
			rf.rFile(filePath);
		} catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
		 request.setAttribute("users","Nimisha from do post" );
		 RequestDispatcher view1 = request.getRequestDispatcher(INSERT_OR_EDIT);
		 view1.forward(request, response);
	}

}
