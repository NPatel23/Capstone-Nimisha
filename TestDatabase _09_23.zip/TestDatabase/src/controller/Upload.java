package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import databaseOp.DatabaseOperations;
import databaseOp.readFile;
import model.FileData;
import model.Resource;;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/Upload")
public class Upload extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    private static String INSERT_OR_EDIT = "/home.jsp";
    private static String INDEXPAGE = "/index.jsp";
    private  DatabaseOperations dao;

    /**
     * Default constructor. 
     */
    public Upload() {
    	super();
    	 dao = new DatabaseOperations();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Running do get");
		
		// TODO Auto-generated method stub
		
		List<FileData> data = GetFileData();
		request.setAttribute("filedata",data);
		System.out.println("Size from upload servlet "+data.size());
		RequestDispatcher view = request.getRequestDispatcher(INSERT_OR_EDIT);
        view.forward(request, response);
	}

	private List<FileData> GetFileData()
	{
		List<FileData> res = new FileData();
		res=dao.getAllFileData();	
		return res;
	}
	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Running do post");
		// TODO Auto-generated method stub
		 readFile rf=new readFile();
		 try {
			rf.rFile("\\TestDatabase\\WebContent\\WEB-INF\\lib\\TimesheetRawData.csv");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        
		 //RequestDispatcher view = request.getRequestDispatcher(INSERT_OR_EDIT);
	     
	     request.setAttribute("users","Nimisha from do post" );
		 RequestDispatcher view1 = request.getRequestDispatcher(INSERT_OR_EDIT);
		 view1.forward(request, response);
	}

}
